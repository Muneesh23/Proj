package com.Classroom.servletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.Classroom.Admin.AdminBean;
import com.inautix.Classroom.Admin.AdminDAO;
//import com.inautix.Classroom.Student.StudentBean;
//import com.inautix.Classroom.Student.StudentDAO;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		boolean login_status = login(request.getParameter("username"), request.getParameter("password"));
		if(login_status == true)
		{
			RequestDispatcher requestDispatch = request.getRequestDispatcher("admin_home.html");
			requestDispatch.forward(request, response);
		}
		else
		{
			//out.print("U r not an authenticated user");
			RequestDispatcher requestDispatch = request.getRequestDispatcher("admin.html");
			requestDispatch.include(request, response);
			out.print("U r not an authenticated user");
		}
		
	}
	public boolean login(String AdminID, String AdminPassword)
	{
		int flag = 0;
		AdminDAO adminDAO = new AdminDAO();
		List<AdminBean> details = adminDAO.getAdminDetails(AdminID);
		Iterator<AdminBean> iterator = details.iterator();
		while(iterator.hasNext())
		{
			AdminBean admin = iterator.next();
			//System.out.print(admin.getAdminID() + " " + admin.getName() + " " + admin.getPassword());
			if(AdminID.equals(admin.getAdminID()) && AdminPassword.equals(admin.getPassword()))
			{
				flag = 1;
			}
		}
		
		if(flag == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
