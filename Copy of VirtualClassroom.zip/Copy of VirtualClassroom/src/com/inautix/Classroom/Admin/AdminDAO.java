package com.inautix.Classroom.Admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class AdminDAO {
	public List getAdminDetails(String AdminId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<AdminBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Admin where AdminID =  '" + AdminId + "'");
			details = new ArrayList<AdminBean>();
			while(result.next())
			{
				AdminBean admin = new AdminBean();
				admin.setAdminID(result.getString(1));
				admin.setName(result.getString(2));
				admin.setPassword(result.getString(3));
				details.add(admin);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Admin set Name = 'Preethi' where AdminID = '" + AdminId +"'");
			//statement.execute("Delete from T_XBBNC94_Staff where AdminID = '" + AdminId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}


}
