package com.inautix.Classroom.Admin;

import java.util.Iterator;
import java.util.List;

import com.inautix.Classroom.Staff.StaffDAO;
import com.inautix.Classroom.Student.*;

public class AdminApp {
	public void login(String AdminID, String AdminPassword)
	{
		int flag = 0;
		AdminDAO adminDAO = new AdminDAO();
		List<AdminBean> details = adminDAO.getAdminDetails(AdminID);
		Iterator<AdminBean> iterator = details.iterator();
		while(iterator.hasNext())
		{
			AdminBean admin = iterator.next();
			//System.out.print(admin.getAdminID() + " " + admin.getName() + " " + admin.getPassword());
			if(AdminID.equals(admin.getAdminID()) && AdminPassword.equals(admin.getPassword()))
			{
				flag = 1;
			}
		}
		if(flag == 1)
		{
			System.out.println("Login Successful");
		}
		else
		{
			System.out.println("Login failed");
		}

	}
	public void updateProfileStudent(String name, String id)
	{
		StudentDAO studentDAO = new StudentDAO();
		studentDAO.updateStudentName(name, id);
	}
	public void updateStudentMark(int Marks, String id)
	{
		StudentDAO studentDAO = new StudentDAO();
		studentDAO.updateStudentMarks(Marks, id);
	}
	public void updateStaffName(String name, String id)
	{
		StaffDAO staffDAO = new StaffDAO();
		staffDAO.updateStaffName(name, id);
	}
	public void updateStaffDesignation(String designation, String id)
	{
		StaffDAO staffDAO = new StaffDAO();
		staffDAO.updateStaffDesignation(designation, id);
	}
	public static void main(String args[])
	{
		String AdminID = "A101";
		String AdminPassword = "admin123";
		AdminApp adminApp = new AdminApp();
		adminApp.login(AdminID, AdminPassword);
		String name = "Muneesh";
		String id = "S101";
		adminApp.updateProfileStudent(name, id);
		int Marks = 100;
		adminApp.updateStudentMark(Marks, id);
		String staffId = "TS101";
		String staffName = "Muneeshwari";
		adminApp.updateStaffName(staffName, staffId);
		String designation = "As.P";
		adminApp.updateStaffDesignation(designation, staffId);
	}
}
