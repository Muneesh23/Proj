Create table T_XBBNC94_Admin (AdminID varchar(20), Name varchar(30));
Insert into T_XBBNC94_Admin (AdminID, Name) values ('A101', 'Priya');
Select * from T_XBBNC94_Admin;
Alter table T_XBBNC94_Admin add Password varchar(30);
Update T_XBBNC94_Admin set Password = 'admin123' where AdminID = 'A101';
Alter table T_XBBNC94_Admin add primary key(AdminID);
