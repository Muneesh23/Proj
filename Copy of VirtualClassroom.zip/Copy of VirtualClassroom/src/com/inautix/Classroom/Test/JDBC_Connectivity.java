package com.inautix.Classroom.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBC_Connectivity {
	
		public static Connection connectToDatabase()
		{
			Connection connection = null;
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			}
			catch(ClassNotFoundException exception)
			{
				exception.printStackTrace();
			}
			try {
				connection = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana", "shobana");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return connection;
		}

	}


