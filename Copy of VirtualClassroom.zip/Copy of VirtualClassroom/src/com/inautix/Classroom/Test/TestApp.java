package com.inautix.Classroom.Test;

import java.util.Iterator;
import java.util.List;

import com.inautix.Classroom.Quiz.QuizBean;
import com.inautix.Classroom.Quiz.QuizDAO;


public class TestApp {
	public void showTestDetails(int number)
	{
		TestDAO testDAO = new TestDAO();
		List<TestBean> details = testDAO.getTestDetails(number);
		Iterator<TestBean> iterator = details.iterator();
		System.out.format("%-20s %-20s\n", "TEST ID", "NAME");
		while(iterator.hasNext())
		{
			TestBean test = iterator.next();
			System.out.printf("%-20s %-20s\n", test.getTestID(), test.getName());
		}
		QuizDAO quizDAO = new QuizDAO();
		List<QuizBean> quizDetails = quizDAO.getQuizDetails(number);
		Iterator<QuizBean> quizIterator = quizDetails.iterator();
		System.out.format("%-20s %-20s %-20s\n","Question No.", "Question", "Options");
		while(quizIterator.hasNext())
		{
			QuizBean quiz = quizIterator.next();
			System.out.printf("%-20s %-20s %-20s\n", quiz.getNumber(), quiz.getQuestion(), quiz.getOptions());
		}
	}
	
	public static void main(String args[])
	{
		int Number = 1;
		TestApp test = new TestApp();
		test.showTestDetails(Number);
	}

}
