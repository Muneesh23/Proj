package com.inautix.Classroom.Test;

public class TestBean {
	private int testID;
	private String name;

	public int getTestID() {
		return testID;
	}
	public void setTestID(int testID) {
		this.testID = testID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
