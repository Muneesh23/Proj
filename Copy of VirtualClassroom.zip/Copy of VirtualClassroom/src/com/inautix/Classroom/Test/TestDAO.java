package com.inautix.Classroom.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class TestDAO {
	public List getTestDetails(int Number)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<TestBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Test where TestID =  '" + Number + "'");
			details = new ArrayList<TestBean>();
			while(result.next())
			{
				TestBean test = new TestBean();
				test.setTestID(Integer.parseInt(result.getString(1)));
				test.setName(result.getString(2));
				details.add(test);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Quiz set Answer = 'C' where Numbers = '" + Number +"'");
			//statement.execute("Delete from T_XBBNC94_Quiz where Numbers = '" + Number + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}


}
