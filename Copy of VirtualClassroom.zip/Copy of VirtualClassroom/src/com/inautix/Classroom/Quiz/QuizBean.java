package com.inautix.Classroom.Quiz;

public class QuizBean {
	private int number, TestID;
	private String question, options, answer;
	public int getTestID() {
		return TestID;
	}
	public void setTestID(int testID) {
		TestID = testID;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	

}
