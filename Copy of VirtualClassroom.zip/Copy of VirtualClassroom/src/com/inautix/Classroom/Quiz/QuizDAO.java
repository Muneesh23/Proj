package com.inautix.Classroom.Quiz;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class QuizDAO {
	public List getQuizDetails(int Number)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<QuizBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Quiz where Numbers =  '" + Number + "'");
			details = new ArrayList<QuizBean>();
			while(result.next())
			{
				QuizBean quiz = new QuizBean();
				quiz.setNumber(Integer.parseInt(result.getString(1)));
				quiz.setQuestion(result.getString(2));
				quiz.setOptions(result.getString(3));
				quiz.setAnswer(result.getString(4));
				quiz.setTestID(Integer.parseInt(result.getString(5)));
				details.add(quiz);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Quiz set Answer = 'C' where Numbers = '" + Number +"'");
			//statement.execute("Delete from T_XBBNC94_Quiz where Numbers = '" + Number + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}

}
