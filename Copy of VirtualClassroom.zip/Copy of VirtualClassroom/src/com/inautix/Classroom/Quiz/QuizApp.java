package com.inautix.Classroom.Quiz;

import java.util.Iterator;
import java.util.List;


public class QuizApp {
	public static void main(String args[])
	{
		int Number = 1;
		QuizDAO quizDAO = new QuizDAO();
		List<QuizBean> details = quizDAO.getQuizDetails(Number);
		Iterator<QuizBean> iterator = details.iterator();
		while(iterator.hasNext())
		{
			QuizBean quiz = iterator.next();
			System.out.println(quiz.getNumber() + " " + quiz.getQuestion() + " " + quiz.getOptions() + " " + quiz.getAnswer());
		}
	}


}
