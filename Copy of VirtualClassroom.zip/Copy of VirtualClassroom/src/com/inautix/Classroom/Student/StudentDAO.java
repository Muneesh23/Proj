package com.inautix.Classroom.Student;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.Classroom.Course.JDBC_Connectivity;
import com.inautix.Classroom.Staff.StaffBean;

public class StudentDAO {
	public List getStudentDetails(String StudentId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<StudentBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Students where StudentID =  '" + StudentId + "'");
			details = new ArrayList<StudentBean>();
			while(result.next())
			{
				StudentBean student = new StudentBean();
				student.setStudentID(result.getString(1));
				student.setName(result.getString(2));
				student.setDepartment(result.getString(3));
				student.setPassword(result.getString(4));
				student.setCourseID(result.getString(5));
				student.setMarks(result.getInt(6));
				details.add(student);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Student set Name = 'Preethi' where StudentID = '" + StudentId +"'");
			//statement.execute("Delete from T_XBBNC94_Student where StudentID = '" + StudentId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}
	public List<StudentBean> getRegisteredStudentDetails(String CourseId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<StudentBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Students where CourseID =  '" + CourseId + "'");
			details = new ArrayList<StudentBean>();
			while(result.next())
			{
				StudentBean student = new StudentBean();
				student.setStudentID(result.getString(1));
				student.setName(result.getString(2));
				student.setDepartment(result.getString(3));
				student.setPassword(result.getString(4));
				student.setCourseID(result.getString(5));
				student.setMarks(result.getInt(6));
				details.add(student);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Student set Name = 'Preethi' where StudentID = '" + StudentId +"'");
			//statement.execute("Delete from T_XBBNC94_Student where StudentID = '" + StudentId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}
	public List<StudentBean> viewTopperDetails(String CourseId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<StudentBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Students where Marks in (Select max(Marks) from T_XBBNC94_Students where CourseID = '" + CourseId + "')");
			details = new ArrayList<StudentBean>();
			while(result.next())
			{
				StudentBean student = new StudentBean();
				student.setStudentID(result.getString(1));
				student.setName(result.getString(2));
				student.setDepartment(result.getString(3));
				student.setPassword(result.getString(4));
				student.setCourseID(result.getString(5));
				student.setMarks(result.getInt(6));
				details.add(student);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Student set Name = 'Preethi' where StudentID = '" + StudentId +"'");
			//statement.execute("Delete from T_XBBNC94_Student where StudentID = '" + StudentId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}
	public List<StudentBean> viewLowScorerDetails(String CourseId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<StudentBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Students where Marks in (Select min(Marks) from T_XBBNC94_Students where CourseID = '" + CourseId + "')");
			details = new ArrayList<StudentBean>();
			while(result.next())
			{
				StudentBean student = new StudentBean();
				student.setStudentID(result.getString(1));
				student.setName(result.getString(2));
				student.setDepartment(result.getString(3));
				student.setPassword(result.getString(4));
				student.setCourseID(result.getString(5));
				student.setMarks(result.getInt(6));
				details.add(student);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Student set Name = 'Preethi' where StudentID = '" + StudentId +"'");
			//statement.execute("Delete from T_XBBNC94_Student where StudentID = '" + StudentId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}
	public List<StudentBean> viewAverageScorerDetails(String CourseId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<StudentBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Students where Marks in (Select avg(Marks) from T_XBBNC94_Students where CourseID = '" + CourseId + "')");
			details = new ArrayList<StudentBean>();
			while(result.next())
			{
				StudentBean student = new StudentBean();
				student.setStudentID(result.getString(1));
				student.setName(result.getString(2));
				student.setDepartment(result.getString(3));
				student.setPassword(result.getString(4));
				student.setCourseID(result.getString(5));
				student.setMarks(result.getInt(6));
				details.add(student);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Student set Name = 'Preethi' where StudentID = '" + StudentId +"'");
			//statement.execute("Delete from T_XBBNC94_Student where StudentID = '" + StudentId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}
	
	public void insertStudentDetails(String Student_id, String Name, String Department, String Password)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.execute("Insert into T_XBBNC94_Students values ('" + Student_id + "', '" + Name + "', '" + Department + "', '" + Password + "')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void updateStudentName(String name, String id)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.execute("Update T_XBBNC94_Students set Name = '" +name +"' where StudentID = '" + id +"'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Student Name updated!!!!!!!!");
	}
	public void updateStudentMarks(int mark, String id)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.execute("Update T_XBBNC94_Students set Marks = '" +mark +"' where StudentID = '" + id +"'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Student Name updated!!!!!!!!");
	}
}
