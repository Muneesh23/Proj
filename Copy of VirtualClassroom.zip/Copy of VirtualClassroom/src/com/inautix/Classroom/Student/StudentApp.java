package com.inautix.Classroom.Student;

import java.util.Iterator;
import java.util.List;

import com.inautix.Classroom.Course.CourseApp;
import com.inautix.Classroom.Test.TestApp;


public class StudentApp {
	public void login(String StudentID, String Password)
	{
		int flag = 0;
		StudentDAO studentDAO = new StudentDAO();
		List<StudentBean> details = studentDAO.getStudentDetails(StudentID);
		Iterator<StudentBean> iterator = details.iterator();
		while(iterator.hasNext())
		{
			StudentBean student = iterator.next();
		//	System.out.print(student.getStudentID() + " " + student.getName() + " " + student.getDepartment());
			if(StudentID.equals(student.getStudentID()) && Password.equals(student.getPassword()))
			{
				flag = 1;
			}
		}
		if(flag == 1)
		{
			System.out.println("Login Successful");
		}
		else
		{
			System.out.println("Login failed");
		}
	}
	public void insertStudentDetails(String Student_id,String Name,String Department,String Student_Password)
	{
		StudentDAO studentDAO = new StudentDAO();
		studentDAO.insertStudentDetails(Student_id, Name, Department, Student_Password);
	}
	public static void main(String args[])
	{
		String StudentID = "S101";
		String Password = "priya23";
		StudentApp studentApp = new StudentApp();
		studentApp.login(StudentID, Password);
		String Student_id = "S102";
		String Name = "Preethi";
		String Department = "IT";
		String Student_Password = "preethi23";
		studentApp.insertStudentDetails(Student_id, Name, Department, Student_Password);
		String CourseID = "IT101";
		CourseApp course = new CourseApp();
		course.showCourseDetails(CourseID);
		int TestID = 1;
		TestApp test = new TestApp();
		test.showTestDetails(TestID);
	}

}
