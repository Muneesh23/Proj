package com.inautix.Classroom.Staff;

import java.util.Iterator;
import java.util.List;



public class StaffApp {
	public void login(String StaffID, String Password)
	{
		int flag = 0;
		StaffDAO staffDAO = new StaffDAO();
		List<StaffBean> details = staffDAO.getStaffDetails(StaffID);
		Iterator<StaffBean> iterator = details.iterator();
		while(iterator.hasNext())
		{
			StaffBean staff = iterator.next();
			//System.out.print(staff.getStaffID() + " " + staff.getName() + " " + staff.getDepartment() + " " + staff.getDesignation());
			if(StaffID.equals(staff.getStaffID()) && Password.equals(staff.getPassword()))
			{
				flag = 1;
			}
		}
		if(flag == 1)
		{
			System.out.println("Login Successful");
		}
		else
		{
			System.out.println("Login failed");
		}
	}
	public void insertStaff(String StaffID, String Name, String Department, String Designation, String Password)
	{
		StaffDAO staffDAO = new StaffDAO();
		staffDAO.insertStaff(StaffID, Name, Department, Designation, Password);
	}
	public static void main(String args[])
	{
		String StaffID = "TS101";
		String Password = "priya23";
		StaffApp staffApp = new StaffApp();
		staffApp.login(StaffID, Password);
		String StaffID_Insert = "TS102";
		String Name = "Preethi";
		String Department = "IT";
		String Designation = "AP";
		String Password_Insert = "preethi23";
		staffApp.insertStaff(StaffID_Insert, Name, Department, Designation, Password_Insert);
	}

}
