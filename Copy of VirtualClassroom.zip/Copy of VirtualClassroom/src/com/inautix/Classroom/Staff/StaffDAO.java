package com.inautix.Classroom.Staff;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.Classroom.Course.JDBC_Connectivity;

public class StaffDAO {
	public List getStaffDetails(String StaffId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<StaffBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Staff where StaffID =  '" + StaffId + "'");
			details = new ArrayList<StaffBean>();
			while(result.next())
			{
				StaffBean staff = new StaffBean();
				staff.setStaffID(result.getString(1));
				staff.setName(result.getString(2));
				staff.setDepartment(result.getString(3));
				staff.setDesignation(result.getString(4));
				staff.setPassword(result.getString(5));
				details.add(staff);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Staff set Name = 'Preethi' where StaffID = '" + StaffId +"'");
			//statement.execute("Delete from T_XBBNC94_Staff where StaffID = '" + StaffId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}
	public void insertStaff(String StaffID, String Name, String Department, String Designation, String Password)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.execute("Insert into T_XBBNC94_Staff values ('" + StaffID + "', '" + Name + "', '" + Department + "', '" + Designation + "', '" + Password + "')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void updateStaffName(String name, String id)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.execute("Update T_XBBNC94_Staff set Name = '" +name +"' where StaffID = '" + id +"'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Staff Name updated!!!!!!!!");
	}
	public void updateStaffDesignation(String designation, String id)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.execute("Update T_XBBNC94_Staff set Designation = '" + designation +"' where StaffID = '" + id +"'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("Staff Designation updated!!!!!!!!");
	}

}
