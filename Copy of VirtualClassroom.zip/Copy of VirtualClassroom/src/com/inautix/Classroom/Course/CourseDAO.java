package com.inautix.Classroom.Course;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {
	public List getCourseDetails(String CourseId)
	{
		Connection connection = JDBC_Connectivity.connectToDatabase();
		Statement statement = null;
		ResultSet result = null;
		List<CourseBean> details = null;
		try {
			statement = connection.createStatement();
			result = statement.executeQuery("Select * from T_XBBNC94_Course where CourseID =  '" + CourseId + "'");
			details = new ArrayList<CourseBean>();
			while(result.next())
			{
				CourseBean course = new CourseBean();
				course.setCourseID(result.getString(1));
				course.setName(result.getString(2));
				course.setCredit(Integer.parseInt(result.getString(3)));
				course.setStartDate(result.getString(4));
				course.setEndDate(result.getString(5));
				course.setDuration_hrs(5);
				course.setType(result.getString(7));
				details.add(course);
			}
			//result.close();
			//statement.executeUpdate("Update T_XBBNC94_Course set Name = 'C' where CourseID = '" + CourseId +"'");
			//statement.execute("Delete from T_XBBNC94_Course where CourseID = '" + CourseId + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				result.close();
				statement.close();
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return details;
	}

}
