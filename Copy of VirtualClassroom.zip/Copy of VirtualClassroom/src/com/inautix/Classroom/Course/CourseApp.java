package com.inautix.Classroom.Course;

import java.util.Iterator;
import java.util.List;

import com.inautix.Classroom.Student.StudentBean;
import com.inautix.Classroom.Student.StudentDAO;

public class CourseApp {
	public void showCourseDetails(String CourseID)
	{
		CourseDAO courseDAO = new CourseDAO();
		List<CourseBean> details = courseDAO.getCourseDetails(CourseID);
		Iterator<CourseBean> iterator = details.iterator();
		System.out.println("\t\t------------------DETAILS ABOUT THE COURSE " + CourseID + "-----------------------");
		while(iterator.hasNext())
		{
			CourseBean course = iterator.next();
			System.out.println("ID: " + course.getCourseID() + "\nNAME: " + course.getName() + "\nCREDITS: " + course.getCredit() + "\nSTART DATE: " + course.getStartDate() + "\nEND DATE: " + course.getEndDate() + "\nDURATION: " + course.getDuration_hrs() + "\nTYPE: " + course.getType());
		}
	}
	public void viewTopper(String CourseID)
	{
		StudentDAO studentDAO = new StudentDAO();
		List<StudentBean> details = studentDAO.viewTopperDetails(CourseID);
		Iterator<StudentBean> iterator = details.iterator();
		System.out.println("\t\t------------------TOPPERS OF " + CourseID + "-----------------------");
		System.out.format("%-20s %-20s %-20s %-20s\n","COURSE ID", "STUDENT ID", "NAME", "MARKS");
		while(iterator.hasNext())
		{
			StudentBean student = iterator.next();
			System.out.printf("%-20s %-20s %-20s %-20s\n", student.getCourseID(), student.getStudentID(), student.getName(), student.getMarks());
		}
	}
	public void viewLowScorer(String CourseID)
	{
		StudentDAO studentDAO = new StudentDAO();
		List<StudentBean> details = studentDAO.viewTopperDetails(CourseID);
		Iterator<StudentBean> iterator = details.iterator();
		System.out.println("\t\t-------------------LOW SCORERS OF " + CourseID + "---------------------");
		System.out.format("%-20s %-20s %-20s %-20s\n","COURSE ID", "STUDENT ID", "NAME", "MARKS");
		while(iterator.hasNext())
		{
			StudentBean student = iterator.next();
			System.out.printf("%-20s %-20s %-20s %-20s\n", student.getCourseID(), student.getStudentID(), student.getName(), student.getMarks());
		}
	}
	public void viewAverageScorer(String CourseID)
	{
		StudentDAO studentDAO = new StudentDAO();
		List<StudentBean> details = studentDAO.viewTopperDetails(CourseID);
		Iterator<StudentBean> iterator = details.iterator();
		System.out.println("\t\t-------------------AVERAGE SCORERS OF " + CourseID + "------------------------");
		System.out.format("%-20s %-20s %-20s %-20s\n","COURSE ID", "STUDENT ID", "NAME", "MARKS");
		while(iterator.hasNext())
		{
			StudentBean student = iterator.next();
			System.out.printf("%-20s %-20s %-20s %-20s\n", student.getCourseID(), student.getStudentID(), student.getName(), student.getMarks());
		}
	}
	public static void main(String args[])
	{
		String CourseID = "IT101";
		CourseApp course = new CourseApp();
		course.viewTopper(CourseID);
		course.viewLowScorer(CourseID);
		course.viewAverageScorer(CourseID);
	}
}
