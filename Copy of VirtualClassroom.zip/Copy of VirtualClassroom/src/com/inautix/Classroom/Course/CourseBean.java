package com.inautix.Classroom.Course;

public class CourseBean {
	private String courseID, name, startDate, endDate, type;
	private int credit, duration_hrs;
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getCredit() {
		return credit;
	}
	public void setCredit(int credit) {
		this.credit = credit;
	}
	public int getDuration_hrs() {
		return duration_hrs;
	}
	public void setDuration_hrs(int duration_hrs) {
		this.duration_hrs = duration_hrs;
	}
}
